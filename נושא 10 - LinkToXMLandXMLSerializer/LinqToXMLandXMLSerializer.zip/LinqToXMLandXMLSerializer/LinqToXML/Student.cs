﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinqToXML
{
    public class Student
    {
        public double Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
