﻿//using System;
//using static DalObject.DalObject;
//using  IDAL.DO;
//using static IDAL.DO.OverloadException;




namespace ConsoleUI
{
    public partial class Program
    {
        static void Main()
        {
            //navigateMenue();
        }
    }
}

