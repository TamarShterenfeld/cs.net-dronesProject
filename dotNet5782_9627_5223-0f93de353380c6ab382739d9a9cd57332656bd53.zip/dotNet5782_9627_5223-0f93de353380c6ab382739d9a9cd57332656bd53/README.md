Gili & Tami Course_2021
# dotNet5782_9627_5223
Project_1_by_Gili_Maman&amp;Tami_Shterenfeld
Good Bye
new line
This is a good idea for writing a code efficiently!
Finally We Are Finishing Project_1