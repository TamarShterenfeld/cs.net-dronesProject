﻿using System;

namespace TemplateSingleTon3
{
    public class Class1
    {
    }
}
